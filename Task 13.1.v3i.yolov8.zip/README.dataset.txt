# Task 13.1 > 2024-09-15 5:44pm
https://universe.roboflow.com/task-13/task-13.1

Provided by a Roboflow user
License: CC BY 4.0

